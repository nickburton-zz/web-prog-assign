My files are stored at:

http://yallara.cs.rmit.edu.au/~cburton/part2/login.php

--

I look at the following resources:

http://au.php.net/fclose
http://au.php.net/fopen
http://au.php.net/explode
http://au.php.net/trim
http://au.php.net/fwrite
http://au.php.net/asort
http://au.php.net/foreach
http://au.php.net/list
http://au.php.net/ereg
http://au.php.net/switch
http://au2.php.net/function.opendir
http://au2.php.net/date

I used Lecture 6.1 example to understand how to write to a file.

--

A tutorial on validating a form at:

http://www.php-mysql-tutorial.com/form-validation-with-php.php

--

Tutorial on file reading at:

http://au.php.net/manual/en/function.fread.php

--

Used Shekhar's example of:
log_in.php, loginfunc.php, editData.php, deleteData, readDir.php.

--

Beginning PHP5 by Mercer, Kent, Nowicki, Squier and Choi is where I learnt about php with radio buttons.

--

Learnt about radio buttons and PHP at:
http://www.homeandlearn.co.uk/php/php4p10.html

--

Tutorial on associatve arrays at:
http://www.tizag.com/phpT/arrays.php

--

Sorting an associative array by value at:
http://www.tech-recipes.com/rx/299/php-syntax-sort-an-associative-array-by-value-with-asort/